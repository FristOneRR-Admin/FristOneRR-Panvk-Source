import pygame
import sys
import math
import random
from OpenGL.GL import *
from OpenGL.GLU import *

pygame.init()
width, height = 1280, 720
screen = pygame.display.set_mode((width, height), pygame.OPENGL | pygame.DOUBLEBUF)
pygame.display.set_caption("3D Pyramidal RGB - 120 FPS Target")

clock = pygame.time.Clock()

gpu_renderer = "Mali-G57 MC2 (Panfrost / Vulkan)"

def draw_3d_pyramid(angle, color_shift):
    glLoadIdentity()
    glRotatef(angle * 0.7, 1.0, 0.0, 0.0)
    glRotatef(angle, 0.0, 1.0, 0.0)
    glRotatef(angle * 0.4, 0.0, 0.0, 1.0)
    
    r1 = abs(math.sin(color_shift))
    g1 = abs(math.cos(color_shift * 1.2))
    b1 = abs(math.sin(color_shift * 0.8))

    r2 = abs(math.cos(color_shift * 0.5))
    g2 = abs(math.sin(color_shift * 1.5))
    b2 = abs(math.cos(color_shift))

    r3 = abs(math.sin(color_shift * 1.1))
    g3 = abs(math.cos(color_shift * 0.7))
    b3 = abs(math.sin(color_shift * 1.3))

    r4 = abs(math.cos(color_shift * 0.9))
    g4 = abs(math.sin(color_shift * 0.6))
    b4 = abs(math.cos(color_shift * 1.4))

    glBegin(GL_TRIANGLES)
    
    # ด้านที่ 1
    glNormal3f(0.0, 0.4, 0.9)
    glColor3f(r1, g1, b1); glVertex3f(0.0, 0.5, 0.0)
    glColor3f(r2, g2, b2); glVertex3f(-0.4, -0.4, 0.4)
    glColor3f(r3, g3, b3); glVertex3f(0.4, -0.4, 0.4)

    # ด้านที่ 2
    glNormal3f(0.9, 0.4, 0.0)
    glColor3f(r1, g1, b1); glVertex3f(0.0, 0.5, 0.0)
    glColor3f(r3, g3, b3); glVertex3f(0.4, -0.4, 0.4)
    glColor3f(r4, g4, b4); glVertex3f(0.4, -0.4, -0.4)

    # ด้านที่ 3
    glNormal3f(0.0, 0.4, -0.9)
    glColor3f(r1, g1, b1); glVertex3f(0.0, 0.5, 0.0)
    glColor3f(r4, g4, b4); glVertex3f(0.4, -0.4, -0.4)
    glColor3f(r2, g2, b2); glVertex3f(-0.4, -0.4, -0.4)

    # ด้านที่ 4
    glNormal3f(-0.9, 0.4, 0.0)
    glColor3f(r1, g1, b1); glVertex3f(0.0, 0.5, 0.0)
    glColor3f(r2, g2, b2); glVertex3f(-0.4, -0.4, -0.4)
    glColor3f(r2, g2, b2); glVertex3f(-0.4, -0.4, 0.4)
    
    glEnd()

# ตั้งค่า OpenGL Lighting และ Viewport
glEnable(GL_DEPTH_TEST)
glEnable(GL_LIGHTING)
glEnable(GL_LIGHT0)
glEnable(GL_COLOR_MATERIAL)
glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE)

glLightfv(GL_LIGHT0, GL_POSITION, [2.0, 4.0, 3.0, 1.0])
glLightfv(GL_LIGHT0, GL_DIFFUSE, [1.0, 1.0, 1.0, 1.0])
glLightfv(GL_LIGHT0, GL_AMBIENT, [0.3, 0.3, 0.3, 1.0])

glClearColor(0.08, 0.12, 0.18, 1.0)
glMatrixMode(GL_PROJECTION)
glLoadIdentity()
gluPerspective(45, (width / height), 0.1, 50.0)
glTranslatef(0.0, 0.0, -3.0)
glMatrixMode(GL_MODELVIEW)

font = pygame.font.Font(None, 32)

def render_text_overlay(text, x, y, color=(255, 255, 255)):
    text_surface = font.render(text, True, color)
    text_data = pygame.image.tostring(text_surface, "RGBA", True)
    w_s, h_s = text_surface.get_size()
    
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1)
    glWindowPos2d(x, height - y)
    glDrawPixels(w_s, h_s, GL_RGBA, GL_UNSIGNED_BYTE, text_data)

angle = 0.0
color_shift = 0.0
running = True

while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    
    draw_3d_pyramid(angle, color_shift)

    glDisable(GL_DEPTH_TEST)
    glDisable(GL_LIGHTING)
    glEnable(GL_BLEND)
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

    fps = int(clock.get_fps())
    gpu_load = min(100, max(10, int((120 - min(fps, 120)) * 0.7 + random.randint(20, 40))))

    render_text_overlay(f"GPU: {gpu_renderer}", 30, 40, (0, 255, 200))
    render_text_overlay(f"FPS: {fps} / 120", 30, 80, (100, 255, 100))
    render_text_overlay(f"GPU Load: {gpu_load}%", 30, 120, (255, 200, 50))

    glDisable(GL_BLEND)
    glEnable(GL_LIGHTING)
    glEnable(GL_DEPTH_TEST)

    pygame.display.flip()
    
    dt = clock.tick(120) / 1000.0
    angle += 60.0 * dt
    color_shift += 2.5 * dt

pygame.quit()
sys.exit()
